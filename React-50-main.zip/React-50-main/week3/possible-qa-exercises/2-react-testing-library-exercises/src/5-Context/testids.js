/**
 * This is the same idea as in the Routing example, have a look at that file for
 * a big explanation of why we do this
 */
export default {
    MYPROFILE_LOGOUT_BUTTON: 'myprofile-logout-button',
    MYPROFILE_LOGGED_OUT_MESSAGE: 'myprofile-logged-out-message',
}
